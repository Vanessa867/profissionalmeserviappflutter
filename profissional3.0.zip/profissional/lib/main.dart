import 'package:flutter/material.dart';
import 'package:profissional/paginas/Agenda.dart';
import 'package:profissional/paginas/Homepage.dart';
import 'package:profissional/paginas/Servitop.dart';
import 'package:profissional/paginas/Superservi%C3%A7o.dart';
import 'package:profissional/paginas/profilepage.dart';
import 'package:profissional/paginas/propostas.dart';
import 'paginas//category_selection.dart';
import 'paginas//subcategory_selection.dart';
import 'paginas/personal_info.dart';
import 'paginas/final_step.dart';
import 'paginas/Mecoins.dart';
import 'paginas/profilepage.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Category Selection',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: CategorySelectionScreen(),
      routes: {
        '/subcategory': (context) => SubcategorySelection(category: ModalRoute.of(context)!.settings.arguments as String),
        '/personalInfo': (context) => PersonalInfoScreen(),
        '/finalStep' : (context) => FinalStepScreen(),
        '/Homepage' : (context) => HomePage(),
        '/SuperServi': (context) => SuperServi(),
        '/Servitop': (context) => Servitop(),
        '/propostas': (context) => Propostaspedi(),
        '/Mecoins': (context) => Mecoins(),
        '/Agenda' : (context) => Agendapage(),
        '/profilepage': (context) => Profiles(),
      },
    );
  }
}
