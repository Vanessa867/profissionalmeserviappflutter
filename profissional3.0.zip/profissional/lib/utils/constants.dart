import 'package:flutter/material.dart';

const Color corPrincipal = Color.fromRGBO(246, 107, 14, 1);
const Color corContainer = Colors.white;
