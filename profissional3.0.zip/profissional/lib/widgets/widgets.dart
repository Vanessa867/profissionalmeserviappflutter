import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:icons_plus/icons_plus.dart';

const Color corPrincipal = Color.fromRGBO(246, 107, 14, 1);
const Color corContainer = Colors.white;


