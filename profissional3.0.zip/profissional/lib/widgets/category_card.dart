import 'package:flutter/material.dart';
import '../utils/constants.dart';

class CategoryCard extends StatelessWidget {
  final String title;
  final VoidCallback onTap;

  CategoryCard({required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        elevation: 4,
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: corPrincipal,
                  fontWeight: FontWeight.w700,
                  fontFamily: "VesperLibre",
                  fontSize: 18.0,
                ),
              ),
              Icon(Icons.arrow_forward, color: corPrincipal),
            ],
          ),
        ),
      ),
    );
  }
}
