package com.example.profissional

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
